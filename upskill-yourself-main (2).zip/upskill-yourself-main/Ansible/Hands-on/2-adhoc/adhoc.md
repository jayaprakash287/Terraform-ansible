# What is adhoc commands?
- An ad-hoc command is something that you might type in to do something really quick but don’t want to save for later.
- Through this session you can understand the basics of what Ansible can do prior to learning the playbook.
- Ad-hoc commands can also be used to do quick things that you might not necessarily want to write as full playbook.
- Generally speaking – The true power of Ansible lies in playbook rite? Then why you would need Ad-hoc tasks?
- Let's assume – You want to power off all your instance for some maintenance purpose and it is once in blue moon activity rite ? In this kind of scenarios you could execute a quick one-liner in Ansible without writing a playbook.
