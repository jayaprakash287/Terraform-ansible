# What is the use of conditionals ?
- often sometimes the result of a play may depend on the value of variable, fact (something fetched from remote system) or previous task results.
- Also, in some cases, the values of variables may depend on other variable. 
- All the above scenarios are covered under this topic how ansible playbook deals with Conditionals. 
