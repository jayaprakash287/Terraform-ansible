# What are we doing with this playbook?
* In this playbooks we are using variables to store actions to be performed

# Code explanation
* `playbook_0 - Generic method` 
   - In this playbook we are declaring variables inside playbook using module `vars`
   - If you are running this code from root user comment lines 3 & 4

* `playbook_1 - Array method` 
   - In this playbook we are declaring variables in list form using module `vars`
   - Also how to call the values using index numbers.
   - If you are running this code from root user comment lines 3 & 4

* `playbook_2 - Dictionary method` 
   - In this playbook we are declaring variables inside playbook in dictionary form using module "vars"
   - Also, how to access any of the value using the key. 
   - If you are running this code from root user comment lines 3 & 4

* `playbook_3 - Extra vars` 
   - In this playbook we are declaring variables inside playbook and providing values of variable from command line using `extra-vars (-e)` argument.
   - If you are running this code from root user comment lines 3 & 4

* `playbook_4 - var_prompt` 
   - When running a playbook, you might want to provide some input at command line in interactive way.
   - This is possible using `vars_prompt`
   - A common usecase for this might be for passing sensitive data that you do not want to record.
   - The user input is hidden by default but it can be made visible by setting `private: no`
   - If you are running this code from root user comment lines 3 & 4

* `playbook_5 - var_files` 
  - Sometimes you may just want to keep certain information in different files, away from the main playbook.
  - You can do this by using an external variables file, or files.
  - This removes the risk of sharing sensitive data with others when sharing your playbook source with them.
  - The contents of each variables file should be simply defined in YAML format.
  - We can use `vars_files` module to call this files.
  - Ensure you are creating a file called `vars.yml` under ansible directory.
  - If you are running this code from root user comment lines 3 & 4

# How to execute playbook?
 - Run playbook on hosts defined in inventory file (default)
   `ansible-playbook playbook_name.yml`

 - Running playbook by passing password
   root user password     : `ansible-playbook playbook_name.yml –k`
   non-root user password : `ansible-playbook playbook_name.yml –K`

 - Run Playbook on single host
   `ansible-playbook playbook_name.yml -i hostname1, hostname2`

 - Run Playbook on custom inventory file
   `ansible-playbook -i inventoryfilename playbook_name.yml`
   
 - Playbook Dry run
   `ansible-playbook playbook_name.yml –check`
  
 - Execute playbook with extra vars
   `ansible-playbook e_vars.yml --extra-vars="package=httpd service=httpd"` 
