# What is the use of variables?
- variable in playbooks are very similar to using variables in any programming language.
- It helps you to use and assign a value to a variable and use that anywhere in the playbook.
- Also one can put condition around the value of variable and accordingly use them in the playbook.
- In playbook we can give a variable in `‘variable_name: variable_value’` format.
- We can use `variable_name` inside single '' or double “” quotes.
- Also with equal (=) notation anywhere in playbook
- Module used for declaring variables inside your playbook is `vars`
