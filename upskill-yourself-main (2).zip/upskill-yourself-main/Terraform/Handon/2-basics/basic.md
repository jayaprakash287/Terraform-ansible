# What can you learn from this example?
* You can learn how to define plugins in configuration file.
* You can learn how to construct blocks with arguments and values.
* What is resource type and where can you find the resource types

# Where to find resource types :

AWS    - https://registry.terraform.io/providers/hashicorp/aws/latest/docs
Azure  - https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs
GCP    - https://registry.terraform.io/providers/hashicorp/google/latest/docs
VMware - https://registry.terraform.io/providers/hashicorp/vsphere/latest/docs