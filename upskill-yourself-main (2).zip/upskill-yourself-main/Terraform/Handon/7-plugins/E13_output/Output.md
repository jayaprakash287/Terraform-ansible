# What is the use of output plugin ?
* Terraform keeps attributes of all the resources you create in form of state file. 
* Those attributes can be queried with help of plugin called output.

# use this plugin?
* generate report with resource information.
* pass resource information to configuration management tools.
* get the resource informations without logging into console.